create trigger CARS_TRG
    before insert
    on CARS
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

