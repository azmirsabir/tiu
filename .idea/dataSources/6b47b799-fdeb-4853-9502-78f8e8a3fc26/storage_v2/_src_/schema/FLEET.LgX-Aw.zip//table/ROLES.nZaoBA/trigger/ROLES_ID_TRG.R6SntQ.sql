create trigger ROLES_ID_TRG
    before insert
    on ROLES
    for each row
begin
            if :new.ID is null then
                select roles_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

