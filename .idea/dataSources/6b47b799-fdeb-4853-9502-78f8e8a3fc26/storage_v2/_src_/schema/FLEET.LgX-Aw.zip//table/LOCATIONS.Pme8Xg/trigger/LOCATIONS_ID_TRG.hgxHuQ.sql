create trigger LOCATIONS_ID_TRG
    before insert
    on LOCATIONS
    for each row
begin
            if :new.ID is null then
                select locations_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

