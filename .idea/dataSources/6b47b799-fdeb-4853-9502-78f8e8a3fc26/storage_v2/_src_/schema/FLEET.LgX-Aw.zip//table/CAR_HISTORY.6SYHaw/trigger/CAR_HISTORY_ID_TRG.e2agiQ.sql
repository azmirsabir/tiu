create trigger CAR_HISTORY_ID_TRG
    before insert
    on CAR_HISTORY
    for each row
begin
            if :new.ID is null then
                select car_history_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

