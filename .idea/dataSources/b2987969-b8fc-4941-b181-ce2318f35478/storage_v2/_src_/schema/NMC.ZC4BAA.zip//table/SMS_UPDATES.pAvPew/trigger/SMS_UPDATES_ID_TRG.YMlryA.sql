create trigger SMS_UPDATES_ID_TRG
    before insert
    on SMS_UPDATES
    for each row
begin
            if :new.ID is null then
                select sms_updates_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

