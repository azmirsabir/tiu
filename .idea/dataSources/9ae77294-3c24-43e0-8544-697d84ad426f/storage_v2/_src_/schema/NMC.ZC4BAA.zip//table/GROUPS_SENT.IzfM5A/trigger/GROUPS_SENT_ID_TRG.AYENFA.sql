create trigger GROUPS_SENT_ID_TRG
    before insert
    on GROUPS_SENT
    for each row
begin
            if :new.ID is null then
                select groups_sent_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

