create trigger USER_GROUPS_ID_TRG
    before insert
    on USER_GROUPS
    for each row
begin
            if :new.ID is null then
                select user_groups_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

