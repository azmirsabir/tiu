create trigger GROUP_MEMBERS_ID_TRG
    before insert
    on GROUP_MEMBERS
    for each row
begin
            if :new.ID is null then
                select group_members_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

