create view SUB_DEALER_VIEW as
select


----------------------------------------------------------sub dealer direct information----------------------------------------------------------------------
upper(sd.SUB_DEALER_CODE) SUB_DEALER_CODE,
sd.SUB_DEALER_SHOP_NAME,
sd.SUB_DEALER_MOTHER_NAME,
sd.SUB_DEALER_BIRTH_DATE,
s.status_value MAIN_STATUS,
ss.sub_status_value SUB_STATUS,

--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------sub dealer contact and name----------------------------------------------------------------------
(select LISTAGG (contacts.SUB_DEALER_CONTACT_VALUE,' - ') within group (order by contacts.SUB_DEALER_CONTACT_VALUE) from  sub_dealer_contact  contacts
where sd.sub_dealer_id = contacts.sub_dealer_ref group by sd.sub_dealer_id) CONTACT,                                              

(select LISTAGG (owners.SUB_DEALER_name_VALUE,' - ') within group (order by owners.SUB_DEALER_name_VALUE) from  sub_dealer_name  owners
where sd.sub_dealer_id = owners.sub_dealer_ref group by sd.sub_dealer_id) OWNER_NAME,
--------------------------------------------------------------------------------------------------------------------------------


-------------------------------------------------------------sub dealer business options-------------------------------------------------------------------
bo.BUSINESS_OWNERSHIP_VALUE BUSINESS_OWNERSHIP,
bc.BUSINESS_condition_VALUE BUSINESS_CONDITION,
bt.BUSINESS_type_VALUE BUSINESS_TYPE,
nsl.ns_license_value NS_LICENSE,

main_ch.channel_value MAIN_CHANNEL,
sub_ch.sub_channel_value SUB_CHANNEL,

cl.class_value CLASS,
--------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------sub dealer location related information ------------------------------------------------------------------
region.region_value REGION,
city.city_value CITY,
zone.zone_value ZONE,
area.area_value AREA,
sub_area.sub_area_value SUB_AREA,
sd.SUB_DEALER_STREET_ADDRESS STREET,
sd.SUB_DEALER_LATITUDE LATITUDE,
sd.SUB_DEALER_LONGITUDE LONGITUDE,
--------------------------------------------------------------------------------------------------------------------------------


------------------------------------------------------sub dealer service line--------------------------------------------------------------------------
service_line.service_line_1,
service_line.service_line_1_md,
service_line.service_line_1_type,

service_line.service_line_2,
service_line.service_line_2_md,
service_line.service_line_2_type,

service_line.service_line_3,
service_line.service_line_3_type,

service_line.service_line_4,
service_line.service_line_4_type,
--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------user access information----------------------------------------------------------------------------
sales_users.user_name SALES,
teamleader_users.user_name TEAMLEADER,


sd.SUB_DEALER_created_at REGISTRATION_DATE,
user_creation.user_name PROFILE_CREATED_BY
--------------------------------------------------------------------------------------------------------------------------------

from sub_dealer                   sd

join location_sub_area                       sub_area on sd.SUB_DEALER_REFERENTIAL_ADDRESS = sub_area.sub_area_id
join location_area                          area on sub_area.area_ref = area.area_id
join location_zone                          zone on area.zone_ref = zone.zone_id
join location_city                         city on zone.city_ref = city.city_id
join location_region                        region on city.region_ref = region.region_id

left join profile_business_type                       bt on bt.business_type_id=sd.sub_dealer_business_type
left join profile_business_ownership                       bo on bo.business_ownership_id=sd.sub_dealer_business_ownership
left join profile_business_condition                        bc on bc.business_condition_id=sd.sub_dealer_business_condition

left join profile_sub_channel                        sub_ch on sub_ch.sub_channel_id=sd.sub_dealer_channel
left join profile_channel                        main_ch on main_ch.channel_id = sub_ch.channel_ref
left join profile_class                        cl on cl.class_id =sd.sub_dealer_class
left join profile_ns_license                   nsl on nsl.NS_LICENSE_ID = sd.sub_dealer_nsl_status


left join profile_sub_status                      ss on ss.sub_status_id=sd.sub_dealer_status
left join profile_status                        s on s.status_id = ss.status_ref
left join users                              user_creation on user_creation.id = sd.sub_dealer_created_by

left join user_access sales_access on ( sales_access.access_reference_id = area.area_id and sales_access.access_type='sales_area')
left join users       sales_users  on sales_access.user_id = sales_users.id

left join user_access teamleader_access on ( teamleader_access.access_reference_id = area.area_id and teamleader_access.access_type='teamleader_area')
left join users       teamleader_users  on teamleader_access.user_id = teamleader_users.id


left join (
    SELECT sub_dealer_ref,
        MAX(DECODE(rn, 1, service_line)) service_line_1,
        MAX(DECODE(rn, 1, main_dealer_value)) service_line_1_md,
        MAX(DECODE(rn, 1, service_line_type_value)) service_line_1_type,
        
        MAX(DECODE(rn, 2, service_line)) service_line_2,
        MAX(DECODE(rn, 2, main_dealer_value)) service_line_2_md,
        MAX(DECODE(rn, 2, service_line_type_value)) service_line_2_type, 
        
        MAX(DECODE(rn, 3, service_line)) service_line_3,
        MAX(DECODE(rn, 3, main_dealer_value)) service_line_3_md,
        MAX(DECODE(rn, 3, service_line_type_value)) service_line_3_type,
        
        MAX(DECODE(rn, 4, service_line)) service_line_4,
        MAX(DECODE(rn, 4, main_dealer_value)) service_line_4_md,
        MAX(DECODE(rn, 4, service_line_type_value)) service_line_4_type 
        
      FROM
       (
           SELECT service_line_sub_dealer sub_dealer_ref, profile_service_line_msisdn service_line, main_dealer_value ,service_line_type_value, ROW_NUMBER() OVER (partition by service_line_sub_dealer order by profile_service_line_id ) rn
           FROM profile_service_line
           join main_dealer on profile_service_line.service_line_main_dealer = main_dealer.main_dealer_id
           join service_line_type on service_line_type.service_line_type_id = profile_service_line.profile_service_line_type
       )
    GROUP BY sub_dealer_ref
) service_line on service_line.sub_dealer_ref = sd.sub_dealer_id

--where sd.sub_dealer_code = 'er05931' for testing
/

