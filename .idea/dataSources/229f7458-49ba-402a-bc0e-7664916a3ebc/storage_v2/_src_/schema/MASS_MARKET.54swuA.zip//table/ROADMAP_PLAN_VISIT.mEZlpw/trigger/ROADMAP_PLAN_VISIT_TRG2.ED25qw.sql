create trigger ROADMAP_PLAN_VISIT_TRG2
    before insert
    on ROADMAP_PLAN_VISIT
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

