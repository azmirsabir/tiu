create trigger ROLE_USER_ID_TRG
    before insert
    on ROLE_USER
    for each row
begin
            if :new.ID is null then
                select role_user_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

