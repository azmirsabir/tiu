create trigger CAR_TRANSACTIONS_ID_TRG
    before insert
    on CAR_TRANSACTIONS
    for each row
begin
            if :new.ID is null then
                select car_transactions_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

