create trigger GPS_DEVICES_ID_TRG
    before insert
    on GPS_DEVICES
    for each row
begin
            if :new.ID is null then
                select gps_devices_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

