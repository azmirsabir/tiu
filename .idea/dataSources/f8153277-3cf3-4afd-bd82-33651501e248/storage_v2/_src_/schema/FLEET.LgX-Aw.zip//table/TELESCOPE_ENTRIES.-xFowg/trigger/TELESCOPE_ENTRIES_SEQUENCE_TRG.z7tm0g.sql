create trigger TELESCOPE_ENTRIES_SEQUENCE_TRG
    before insert
    on TELESCOPE_ENTRIES
    for each row
begin
            if :new."SEQUENCE" is null then
                select telescope_entries_sequence_seq.nextval into :new."SEQUENCE" from dual;
            end if;
            end;
/

