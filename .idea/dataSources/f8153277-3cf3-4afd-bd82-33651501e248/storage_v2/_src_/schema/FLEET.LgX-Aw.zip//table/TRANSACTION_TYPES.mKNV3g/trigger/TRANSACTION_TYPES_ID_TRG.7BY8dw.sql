create trigger TRANSACTION_TYPES_ID_TRG
    before insert
    on TRANSACTION_TYPES
    for each row
begin
            if :new.ID is null then
                select transaction_types_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

