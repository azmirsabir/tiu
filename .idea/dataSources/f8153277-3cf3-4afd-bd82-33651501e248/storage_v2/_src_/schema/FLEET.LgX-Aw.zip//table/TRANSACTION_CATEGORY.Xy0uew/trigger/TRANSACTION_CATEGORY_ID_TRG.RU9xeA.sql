create trigger TRANSACTION_CATEGORY_ID_TRG
    before insert
    on TRANSACTION_CATEGORY
    for each row
begin
            if :new.ID is null then
                select transaction_category_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

