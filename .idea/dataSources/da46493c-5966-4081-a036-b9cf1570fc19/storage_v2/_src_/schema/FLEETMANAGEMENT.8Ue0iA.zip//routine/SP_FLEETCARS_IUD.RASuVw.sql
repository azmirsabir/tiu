create PROCEDURE "SP_FLEETCARS_IUD" 
(
  p_car_id                 in   number,
  p_car_name               in   varchar2,
  p_plate_no               in  varchar2,
  p_color                  in   varchar2,
  p_model                  in   number,
  p_vin_no                 in   varchar2,
  p_cylinder               in   number,
  p_km_fuel                in   varchar2,
  p_ownership_exp_date     in   varchar2,
  p_inssurance_exp_date    in   varchar2,
  p_department_id          in   number,
  p_location_id            in   number,
  p_ownership_sts_id       in   number,
  p_vpi_exp_date           in   varchar2,
  p_gps_id                 in   number,
  p_user_name              in   varchar2,
  p_action                 in   number,
  p_status                 out  number
)
is
  v_cars_exists number :=0;
  v_car_seq number:=cars_seq.nextval;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_cars_exists from fleet_cars_tbl where upper(p_plate_no)=upper(plate_no) and upper(p_car_name)=upper(car_name);
    if v_cars_exists=0 then
    insert into fleet_cars_tbl columns (car_id,car_name,plate_no,color,model,vin_no,cylinder,km_fuel,ownership_exp_date,inssurance_exp_date,department_id,location_id,user_name,rec_date,ownership_sts_id,vpi_exp_date,gps_id)
    values (v_car_seq,p_car_name,p_plate_no,p_color,p_model,p_vin_no,p_cylinder,p_km_fuel,p_ownership_exp_date,p_inssurance_exp_date,p_department_id,p_location_id,p_user_name,sysdate,p_ownership_sts_id,p_vpi_exp_date,p_gps_id);
    ---insert done successfully
    insert into fleet_cars_trans_tbl columns (cars_trans_id,car_id,car_name,plate_no,location_id,department_id,
    cars_trans_typeid,user_name,rec_date,gps_id)
values(cars_trans_seq.nextval,v_car_seq,p_car_name,p_plate_no,p_location_id,p_department_id,p_action,p_user_name,sysdate,p_gps_id);

    p_status:=0;
    else
    ---Car name with the same palte number already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
  select count(*) into v_cars_exists from fleet_trans_tbl where car_id=p_car_id;
  if v_cars_exists=0 then

insert into fleet_cars_trans_tbl 
select cars_trans_seq.nextval,car_id,car_name,plate_no,location_id,department_id,p_action,p_user_name,
sysdate,gps_id from fleet_cars_tbl
where car_id=p_car_id;

update fleet_cars_tbl set car_name=p_car_name,plate_no=p_plate_no,color=p_color,
model=p_model,vin_no=p_vin_no,cylinder=p_cylinder,km_fuel=p_km_fuel,
ownership_exp_date=p_ownership_exp_date,inssurance_exp_date=p_inssurance_exp_date,
department_id=p_department_id,location_id=p_location_id,ownership_sts_id=p_ownership_sts_id,vpi_exp_date=p_vpi_exp_date,
gps_id=p_gps_id,user_name=p_user_name,rec_date=sysdate  where car_id=p_car_id;
    ---update done successfully
    p_status:=0;
    else
    ----Transactyion type Name Already Existed
      p_status:=1;
      end if;
  end if;
  ---delete Action

  if p_action=3 then

select count(*) into v_cars_exists from fleet_trans_tbl where car_id=p_car_id;
if v_cars_exists=0 then

insert into fleet_cars_trans_tbl 
select cars_trans_seq.nextval,car_id,car_name,plate_no,location_id,department_id,p_action,p_user_name,
sysdate,gps_id from fleet_cars_tbl
where car_id=p_car_id;

delete fleet_cars_tbl where car_id=p_car_id;   

    ---delete done successfuly
    p_status:=0;
    else
    ----Car already existed in transactions can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
----transfer-------
 if p_action=4 then

insert into fleet_cars_trans_tbl 
select cars_trans_seq.nextval,car_id,car_name,plate_no,location_id,department_id,p_action,p_user_name,
sysdate,gps_id from fleet_cars_tbl
where car_id=p_car_id;

update fleet_cars_tbl set 
department_id=p_department_id,location_id=p_location_id  where car_id=p_car_id; 
---Transfer done successfuly
p_status:=0;

end if;

end SP_FleetCars_IUD;
/

