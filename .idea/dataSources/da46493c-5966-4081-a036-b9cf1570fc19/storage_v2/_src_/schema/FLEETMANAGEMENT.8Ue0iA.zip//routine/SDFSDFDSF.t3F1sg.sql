create PROCEDURE sdfsdfdsf (employee_id NUMBER) AS
   BEGIN
     insert into logger values('sfds','sdfsdf');
   END;
/

