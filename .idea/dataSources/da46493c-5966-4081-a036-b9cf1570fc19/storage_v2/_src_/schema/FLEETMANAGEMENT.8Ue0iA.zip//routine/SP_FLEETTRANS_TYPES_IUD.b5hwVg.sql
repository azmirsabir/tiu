create PROCEDURE "SP_FLEETTRANS_TYPES_IUD" 
(
  p_trans_type_id                in   number,
  p_trans_type_desc              in   varchar2,
  p_main_trans_type_id           in   number,
  p_action                       in   number,
  p_status                       out  number
)
is
  v_trans_type_exists number :=0;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_trans_type_exists from fleet_trans_type_tbl where upper(p_trans_type_desc)=upper(trans_type_desc);
    if v_trans_type_exists=0 then
    insert into fleet_trans_type_tbl values (fleet_transactions_type_seq.nextval,p_trans_type_desc,p_main_trans_type_id);
    ---insert done successfully
    p_status:=0;
    else
    ---Transaction type name already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
  select count(*) into v_trans_type_exists from fleet_trans_type_tbl where upper(p_trans_type_desc)=upper(trans_type_desc) and main_trans_type_id=p_main_trans_type_id;
  if v_trans_type_exists=0 then
    update fleet_trans_type_tbl set trans_type_desc=p_trans_type_desc,main_trans_type_id=p_main_trans_type_id where trans_type_id=p_trans_type_id;
    ---update done successfully
    p_status:=0;
    else
    ----Transactyion type Name Already Existed
      p_status:=1;
      end if;
  end if;
  ---delete Action
  if p_action=3 then
    select count(*) into v_trans_type_exists from fleet_trans_tbl where trans_type_id=p_trans_type_id;
    if v_trans_type_exists=0 then
    delete fleet_trans_type_tbl where trans_type_id=p_trans_type_id;
    ---delete done successfuly
    p_status:=0;
    else
    ----transaction type already existed in transactions can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
end SP_FleetTrans_types_IUD;
/

