create PROCEDURE "SP_FLEETGPS_IUD" 
(
  p_gps_id                       in   number,
  p_sim_number                   in   varchar2,
  p_action                       in   number,
  p_status                       out  number
)
is
  v_gps_exists number :=0;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_gps_exists from fleet_gpsdevices_tbl where p_gps_id=gps_id;
    if v_gps_exists=0 then
    insert into fleet_gpsdevices_tbl values (p_gps_id,p_sim_number);
    ---insert done successfully
    p_status:=0;
    else
    ---GPS Name already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
 /* select count(*) into v_gps_exists from fleet_gpsdevices_tbl where p_gps_id=gps_id;
  if v_gps_exists=0 then*/
    update fleet_gpsdevices_tbl set sim_number=p_sim_number where gps_id=p_gps_id;
    ---update done successfully
    p_status:=0;
/*    else
    ----Location Name Already Existed
      p_status:=1;
      end if;*/
  end if;
  ---delete Action
  if p_action=3 then
    select count(*) into v_gps_exists from fleet_cars_tbl where gps_id=p_gps_id;
    if v_gps_exists=0 then
    delete fleet_cars_tbl where gps_id=p_gps_id;
    ---delete done successfuly
    p_status:=0;
    else
    ----Location already defined for Drivers can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
end SP_FleetGPS_IUD;
/

