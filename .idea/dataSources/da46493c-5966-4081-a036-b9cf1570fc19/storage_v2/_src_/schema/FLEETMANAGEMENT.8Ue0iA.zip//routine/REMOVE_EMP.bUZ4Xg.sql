create PROCEDURE remove_emp (employee_id NUMBER) AS
   BEGIN
     insert into logger('sfds','sdfsdf');
   END;
/

