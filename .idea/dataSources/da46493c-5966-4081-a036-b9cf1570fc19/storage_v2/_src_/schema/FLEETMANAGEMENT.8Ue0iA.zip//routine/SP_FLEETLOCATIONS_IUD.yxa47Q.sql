create PROCEDURE "SP_FLEETLOCATIONS_IUD" 
(
  p_location_id                  in   number,
  p_location_name                in   varchar2,
  p_action                       in   number,
  p_status                       out  number
)
is
  v_location_exists number :=0;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_location_exists from fleet_locations_Tbl where upper(p_location_name)=upper(location_name);
    if v_location_exists=0 then
    insert into fleet_locations_Tbl values (locations_seq.nextval,p_location_name);
    ---insert done successfully
    p_status:=0;
    else
    ---location Name already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
  select count(*) into v_location_exists from fleet_locations_Tbl where upper(p_location_name)=upper(location_name);
  if v_location_exists=0 then
    update fleet_locations_Tbl set location_name=p_location_name where location_id=p_location_id;
    ---update done successfully
    p_status:=0;
    else
    ----Location Name Already Existed
      p_status:=1;
      end if;
  end if;
  ---delete Action
  if p_action=3 then
    select count(*) into v_location_exists from fleet_drivers_tbl where location_id=p_location_id;
    if v_location_exists=0 then
    delete fleet_locations_Tbl where location_id=p_location_id;
    ---delete done successfuly
    p_status:=0;
    else
    ----Location already defined for Drivers can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
end SP_FleetLocations_IUD;
/

