create PROCEDURE "SP_FLEETCARSCONTRACTS_IUD" 
(
  p_contract_id            in   number,
  p_car_id                 in   number,
  p_driver_id              in   number,
  p_department_id          in   number,
  p_location_id            in   number,
  p_contract_strt_date     in   varchar2,
  p_contract_end_date      in   varchar2,
  p_monthly_amount         in   number,
  p_contract_sts_id        in   number,
  p_user_name              in   varchar2,
  p_action                 in   number,
  p_status                 out  number
)
is
  v_CarContract_exists number :=0;
  v_carContract_seq number:=cars_contract_seq.nextval;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_CarContract_exists from fleet_cars_contracts_tbl where car_id=p_car_id;
    if v_CarContract_exists=0 then
    insert into fleet_cars_contracts_tbl columns (contract_id,car_id,driver_id,department_id,location_id,
    contract_strt_date,contract_end_date,monthly_amount,contract_sts_id,total_amount,user_name,rec_date)
    values (v_carContract_seq,p_car_id,p_driver_id,p_department_id,p_location_id,p_contract_strt_date,p_contract_end_date,
    p_monthly_amount,p_contract_sts_id,round(MONTHS_BETWEEN(to_date(p_contract_end_date,'mm/dd/yyyy'), to_date(p_contract_strt_date,'mm/dd/yyyy')),1 ) * p_monthly_amount,p_user_name,sysdate);
    ---insert done successfully
    insert into fleet_contracts_trans_tbl columns (contract_id,car_id,driver_id,department_id,location_id,
    contract_strt_date,contract_end_date,monthly_amount,contract_sts_id,total_amount,user_name,rec_date,contract_trans_type_id)
    values (v_carContract_seq,p_car_id,p_driver_id,p_department_id,p_location_id,p_contract_strt_date,p_contract_end_date,
    p_monthly_amount,p_contract_sts_id,round(MONTHS_BETWEEN(to_date(p_contract_end_date,'mm/dd/yyyy'), to_date(p_contract_strt_date,'mm/dd/yyyy')),1 ) * p_monthly_amount,p_user_name,sysdate,p_action);

    p_status:=0;
    else
    ---Car Contract already exist.
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
/*  select count(*) into v_CarContract_exists from fleet_cars_contracts_tbl where car_id=p_car_id;
  if v_CarContract_exists=0 then*/

  insert into fleet_contracts_trans_tbl columns (contract_id,car_id,driver_id,department_id,location_id,
    contract_strt_date,contract_end_date,monthly_amount,contract_sts_id,total_amount,user_name,rec_date,contract_trans_type_id)
    values (v_carContract_seq,p_car_id,p_driver_id,p_department_id,p_location_id,p_contract_strt_date,p_contract_end_date,
    p_monthly_amount,p_contract_sts_id,round(MONTHS_BETWEEN(to_date(p_contract_end_date,'mm/dd/yyyy'), to_date(p_contract_strt_date,'mm/dd/yyyy')),1 ) * p_monthly_amount,p_user_name,sysdate,p_action);

update fleet_cars_contracts_tbl set car_id=p_car_id,driver_id=p_driver_id,department_id=p_department_id,
location_id=p_location_id,contract_strt_date=p_contract_strt_date,contract_end_date=p_contract_end_date,monthly_amount=p_monthly_amount,
contract_sts_id=p_contract_sts_id,
/*total_amount=round(months_between(p_contract_end_date,p_contract_end_date),1)* p_monthly_amount,*/
total_amount=round(MONTHS_BETWEEN(to_date(p_contract_end_date,'mm/dd/yyyy'), to_date(p_contract_strt_date,'mm/dd/yyyy')),1 ) * p_monthly_amount,
user_name=p_user_name,rec_date=sysdate  where contract_id=p_contract_id;
    ---update done successfully
    p_status:=0;
/*    else*/
    ----Car Contract already exist.
/*      p_status:=1;
      end if;*/
  end if;
  ---delete Action

  if p_action=3 then

select count(*) into v_CarContract_exists from fleet_trans_tbl where car_id=p_car_id;
if v_CarContract_exists=0 then

insert into fleet_contracts_trans_tbl
select contract_id,car_id,driver_id,department_id,location_id,contract_strt_date,contract_end_date,
monthly_amount,p_user_name,sysdate,total_amount,contract_sts_id,p_action from fleet_cars_contracts_tbl
where contract_id=p_contract_id;

delete fleet_cars_contracts_tbl where contract_id=p_contract_id;

    ---delete done successfuly
    p_status:=0;
    else
    ----Car already existed in transactions can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;


end SP_FleetCarsContracts_IUD;
/

