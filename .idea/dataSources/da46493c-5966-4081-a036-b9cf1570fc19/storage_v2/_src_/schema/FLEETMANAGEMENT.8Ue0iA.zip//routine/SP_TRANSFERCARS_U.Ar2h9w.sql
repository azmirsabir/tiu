create PROCEDURE "SP_TRANSFERCARS_U" 
(
  p_car_id                 in   number,
  p_department_id          in   number,
  p_location_id            in   number,
  p_user_name              in   varchar2,
  p_action                  in   number
)
is
  v_cars_exists number :=0;
begin
-----Transfer action

insert into fleet_cars_trans_tbl 
select cars_trans_seq.nextval,car_id,car_name,plate_no,location_id,department_id,p_action,p_user_name,
sysdate,null from fleet_cars_tbl
where car_id=p_car_id;

update fleet_cars_tbl set 
department_id=p_department_id,location_id=p_location_id  where car_id=p_car_id;
---update done successfully

end SP_TransferCars_U;
/

