create PROCEDURE "SP_FLEETDEPARTMENTS_IUD" 
(
  p_department_id                  in   number,
  p_department_name                in   varchar2,
  p_action                       in   number,
  p_status                       out  number
)
is
  v_department_exists number :=0;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_department_exists from fleet_departments_tbl where upper(p_department_name)=upper(department_name);
    if v_department_exists=0 then
    insert into fleet_departments_tbl values (departments_seq.nextval,p_department_name);
    ---insert done successfully
    p_status:=0;
    else
    ---department Name already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
  select count(*) into v_department_exists from fleet_departments_tbl where upper(p_department_name)=upper(department_name);
  if v_department_exists=0 then
    update fleet_departments_tbl set department_name=p_department_name where department_id=p_department_id;
    ---update done successfully
    p_status:=0;
    else
    ----Department Name Already Existed
      p_status:=1;
      end if;
  end if;
  ---delete Action
  if p_action=3 then
    select count(*) into v_department_exists from          
(select department_id from fleet_cars_tbl 
union all select department_id from fleet_drivers_tbl )
where department_id=p_department_id;
    if v_department_exists=0 then
    delete fleet_departments_tbl where department_id=p_department_id;
    ---delete done successfuly
    p_status:=0;
    else
    ----Department already defined for cars can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
end SP_FleetDepartments_IUD;
/

