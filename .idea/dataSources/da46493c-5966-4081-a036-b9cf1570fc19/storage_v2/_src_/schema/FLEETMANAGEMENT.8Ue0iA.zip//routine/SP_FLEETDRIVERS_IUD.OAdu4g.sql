create PROCEDURE "SP_FLEETDRIVERS_IUD" 
(
  p_driver_id                in   number,
  p_driver_name              in   varchar2,
  p_mob_no                   in   varchar2,
  p_location_id              in   number,
  p_contract_date            in varchar2,
  p_department_id            in number,
  p_license_exp_date         in varchar2,
  p_user_name                in varchar2,
  p_action                   in   number,
  p_status                   out  number
)
is
  v_drivers_exists number :=0;
begin
----Insert Action
  if p_action=1 then
    select count(*) into v_drivers_exists from fleet_drivers_tbl where upper(p_driver_name)=upper(driver_name);
    if v_drivers_exists=0 then
    insert into fleet_drivers_tbl columns (driver_id,driver_name,mob_no,location_id,contract_date,department_id,license_exp_date,user_name,rec_date)
     values (drivers_seq.nextval,p_driver_name,p_mob_no,p_location_id,p_contract_date,p_department_id,p_license_exp_date,p_user_name,sysdate);
    ---insert done successfully
    p_status:=0;
    else
    ---Transaction type name already Created
      p_status:=1;
      end if;
end if;
-----Update action
if p_action=2 then
/*  select count(*) into v_drivers_exists from fleet_drivers_tbl where upper(p_driver_name)=upper(driver_name);
  if v_drivers_exists=0 then*/
    update fleet_drivers_tbl set driver_name=p_driver_name,mob_no=p_mob_no,location_id=p_location_id,contract_date=p_contract_date,department_id=p_department_id,
    license_exp_date=p_license_exp_date,user_name=p_user_name,rec_date=sysdate where driver_id=p_driver_id;
    ---update done successfully
    p_status:=0;
/*    else
    ----driver  Name Already Existed
      p_status:=1;
      end if;*/
  end if;
  ---delete Action
  if p_action=3 then
    select count(*) into v_drivers_exists from fleet_trans_tbl where driver_id=p_driver_id;
    if v_drivers_exists=0 then
    delete fleet_drivers_tbl where driver_id=p_driver_id;
    ---delete done successfuly
    p_status:=0;
    else
    ----Driver already existed in transactions can not be deleted for history maintaining purposes.
      p_status:=1;
      end if;
    end if;
end SP_fleetdrivers_IUD;
/

