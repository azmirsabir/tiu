create PROCEDURE "SP_FLEETTRANSACTIONS_IUD" 
(
  p_trans_id                in   number,
  p_trans_type_id           in   number,
  p_car_id                  in   number,
  p_driver_id               in   number,
  p_milage                  in number,
  p_liter                   in number,
  p_details                 in varchar2,
  p_description             in varchar2,
  p_amount                   in number,
  p_transaction_date        in varchar2,
  p_user_name               in varchar2,
  p_action                  in   number,
  p_status                  out  number
)
is
  v_drivers_exists number :=0;
  v_location number:=0;
  v_department number:=0;
  v_trans_seq number:=fleet_transactions_seq.nextval;
begin


  insert into jtem_debuger values('p_description',p_description);
  insert into jtem_debuger values('p_milage',p_milage);  

  insert into jtem_debuger values('p_action',p_action);    



   if p_action in(1,2) then
  select location_id into v_location from fleet_cars_tbl where car_id=p_car_id;
  select department_id into v_department from fleet_cars_Tbl where car_id=p_car_id;
  end if;
----Insert Action
  if p_action=1 then
    insert into fleet_trans_tbl columns (trans_id,trans_type_id,car_id,driver_id,milage,liter,details,description,amount,transaction_date,user_name,rec_date,location_id,department_id)
     values (v_trans_seq,p_trans_type_id,p_car_id,p_driver_id,p_milage,p_liter,p_details,p_description,p_amount,p_transaction_date,p_user_name,sysdate,v_location,v_department);
    ---insert done successfully
    insert into jtem_debuger values('insert done successfully','insert done successfully');

      insert into fleet_trans_logs_tbl columns (trans_id,trans_type_id,car_id,driver_id,milage,liter,details,description,amount,transaction_date,user_name,rec_date,location_id,department_id,fleet_action_typeid)
     values (v_trans_seq,p_trans_type_id,p_car_id,p_driver_id,p_milage,p_liter,p_details,p_description,p_amount,p_transaction_date,p_user_name,sysdate,v_location,v_department,p_action);
     p_status:=0;
end if;
-----Update action
if p_action=2 then

    insert into fleet_trans_logs_tbl
    select trans_id,trans_type_id,car_id,driver_id,milage,liter,details,description,amount,
    user_name,rec_date,transaction_date,location_id,department_id,p_action from fleet_trans_tbl
    where trans_id=p_trans_id;

    update fleet_trans_tbl set trans_type_id=p_trans_type_id,car_id=p_car_id,driver_id =p_driver_id,milage=p_milage,liter=p_liter,details=p_details,
    description=p_description,amount=p_amount ,transaction_date=p_transaction_date,user_name=p_user_name,rec_date=sysdate,location_id=v_location,department_id=v_department where trans_id=p_trans_id;
    ---update done successfully
     p_status:=0;
  end if;
  ---delete Action
if p_action=3 then

    insert into fleet_trans_logs_tbl
    select trans_id,trans_type_id,car_id,driver_id,milage,liter,details,description,amount,
    user_name,rec_date,transaction_date,location_id,department_id,p_action from fleet_trans_tbl
    where trans_id=p_trans_id;

    delete fleet_trans_tbl where trans_id=p_trans_id;
    ---delete done successfuly
     p_status:=0;

    end if;
end SP_fleetTransactions_IUD;
/

