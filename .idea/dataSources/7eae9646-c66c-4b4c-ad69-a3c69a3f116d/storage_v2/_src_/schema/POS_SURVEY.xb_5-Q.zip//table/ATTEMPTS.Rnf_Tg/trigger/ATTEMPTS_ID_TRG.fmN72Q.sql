create trigger ATTEMPTS_ID_TRG
    before insert
    on ATTEMPTS
    for each row
begin
            if :new.ID is null then
                select attempts_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

