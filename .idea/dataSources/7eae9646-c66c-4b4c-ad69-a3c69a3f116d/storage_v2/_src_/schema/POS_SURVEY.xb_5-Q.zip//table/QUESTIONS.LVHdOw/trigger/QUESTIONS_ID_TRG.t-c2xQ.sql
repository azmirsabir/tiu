create trigger QUESTIONS_ID_TRG
    before insert
    on QUESTIONS
    for each row
begin
            if :new.ID is null then
                select questions_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

